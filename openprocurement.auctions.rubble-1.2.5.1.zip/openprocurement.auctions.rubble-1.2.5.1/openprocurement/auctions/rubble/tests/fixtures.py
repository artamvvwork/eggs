PARTIAL_MOCK_CONFIG = {
    "auctions.rubble.financial":{
        "use_default":True,
        "plugins":{
            "rubble.financial.migration":None
        },
        "migration":False,
        "aliases":[],
        "accreditation": {
            "create": [1],
            "edit": [2]
        }
    },
    "auctions.rubble.other":{
        "use_default":True,
        "plugins":{
            "rubble.other.migration":None
        },
        "migration":False,
        "aliases":[],
        "accreditation": {
            "create": [1],
            "edit": [2]
        }
    }
}
