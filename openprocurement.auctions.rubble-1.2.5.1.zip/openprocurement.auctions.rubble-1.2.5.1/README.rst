.. image:: https://travis-ci.org/openprocurement/openprocurement.auctions.dgf.svg?branch=master
    :target: https://travis-ci.org/openprocurement/openprocurement.auctions.dgf

.. image:: https://coveralls.io/repos/github/openprocurement/openprocurement.auctions.dgf/badge.svg
  :target: https://coveralls.io/github/openprocurement/openprocurement.auctions.dgf

.. image:: https://img.shields.io/hexpm/l/plug.svg
    :target: https://github.com/openprocurement/openprocurement.auctions.dgf/blob/master/LICENSE.txt


Introduction
============

openprocurement.auctions.dgf repository contains code for Deposit Guarantee Fund auctions.

Documentation can be found here http://dgf.api-docs.openprocurement.org/uk/latest/

