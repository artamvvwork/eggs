openprocurement.client.python
=============================

|Build Status| |Coverage Status|

Reference implementation of a client for OpenProcurement API.


.. |Build Status| image:: https://travis-ci.org/openprocurement/openprocurement.client.python.svg?branch=master
   :target: https://travis-ci.org/openprocurement/openprocurement.client.python
.. |Coverage Status| image:: https://coveralls.io/repos/openprocurement/openprocurement.client.python/badge.svg?branch=master&service=github
   :target: https://coveralls.io/github/openprocurement/openprocurement.client.python?branch=master
